﻿using LabaratoryApplication.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LabaratoryApplication
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PasswordVisibility_checkBox_Checked(object sender, RoutedEventArgs e)
        {
            Password_passwordBox.Visibility = Visibility.Hidden;
            Password_textBox.Visibility = Visibility.Visible;
            Password_textBox.Text = Password_passwordBox.Password;
        }
        int misstake = 0;
        public bool correctCapthaAnswer = false;
        private void Authorization_button_Click(object sender, RoutedEventArgs e)
        {
            string password = "";
            if(PasswordVisibility_checkBox.IsChecked == true)
                password = Password_textBox.Text;
            else
                password = Password_passwordBox.Password;
            if (App.Database.User.Where
                (data => data.login == Login_textBox.Text
                && data.password == password).Count() > 0)
            {
                User user = App.Database.User.Where
                    (data => data.login == Login_textBox.Text
                    && data.password == password).First();
                try
                {
                    UserLog userLog = new UserLog();
                    userLog.user = user.id;
                    userLog.date_authorization = DateTime.Now;
                    userLog.status = true;
                    App.Database.UserLog.Add(userLog);
                    App.Database.SaveChanges();
                }
                catch
                {

                }
                switch (user.type)
                {
                    case 1: //Лаборант
                        LaborantWindow laborantWindow = new LaborantWindow(user.fullName);
                        laborantWindow.Show();
                        this.Close();
                        break;
                    case 2: //Бухгалтер
                        BuchgalterWindow buchgalterWindow = new BuchgalterWindow(user.fullName);
                        buchgalterWindow.Show();
                        this.Close();
                        break;
                    case 3: //Администратор
                        AdministratorWindow administratorWindow = new AdministratorWindow();
                        administratorWindow.Show();
                        this.Close();
                        break;
                }
            }
            else
            {
                try
                {
                    User user = App.Database.User.Where
                    (data => data.login == Login_textBox.Text
                    ).First();
                    UserLog userLog = new UserLog();
                    userLog.user = user.id;
                    userLog.date_authorization = DateTime.Now;
                    userLog.status = false;
                    App.Database.UserLog.Add(userLog);
                    App.Database.SaveChanges();
                }
                catch 
                {
                
                }
                MessageBox.Show("Данного пользователя не существует","Ошибка");
                Captha captha = new Captha(AuthorizationForm);
                captha.ShowDialog();
                if (correctCapthaAnswer)
                {
                }
                else
                {
                    System.Windows.Threading.DispatcherTimer timer = new System.Windows.Threading.DispatcherTimer();
                    timer.Tick += new EventHandler(timer_Tick);
                    timer.Interval = new TimeSpan(0, 0, 10);
                    Login_textBox.IsEnabled = false;
                    PasswordVisibility_checkBox.IsEnabled = false;
                    Password_passwordBox.IsEnabled = false;
                    Password_textBox.IsEnabled = false;
                    Out_button.IsEnabled = false;
                    Authorization_button.IsEnabled = false;
                    timer.Start();
                }
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            Login_textBox.IsEnabled = true;
            PasswordVisibility_checkBox.IsEnabled = true;
            Password_passwordBox.IsEnabled = true;
            Password_textBox.IsEnabled = true;
            Out_button.IsEnabled = true;
            Authorization_button.IsEnabled = true;
        }

        private void Out_button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PasswordVisibility_checkBox_Unchecked(object sender, RoutedEventArgs e)
        {
            Password_passwordBox.Visibility = Visibility.Visible;
            Password_textBox.Visibility = Visibility.Hidden;
            Password_passwordBox.Password = Password_textBox.Text;
        }
    }
}
