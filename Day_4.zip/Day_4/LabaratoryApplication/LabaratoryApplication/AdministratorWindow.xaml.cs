﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LabaratoryApplication
{
    /// <summary>
    /// Логика взаимодействия для AdministratorWindow.xaml
    /// </summary>
    public partial class AdministratorWindow : Window
    {
        public AdministratorWindow()
        {
            InitializeComponent();
            UserLogList.ItemsSource = App.Database.UserLog.ToList();
        }

        private void Find_textBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (App.Database.User.Where
                (log => log.login == Find_textBox.Text).Count() > 0)
            {
                UserLogList.ItemsSource = App.Database.UserLog.Where
                    (log => log.user == App.Database.User.Where
                (user => user.login == Find_textBox.Text).FirstOrDefault().id)
                    .ToList();
            }
            else
            {
                UserLogList.ItemsSource = App.Database.UserLog.ToList();
            }
        }

        private void Find_textBox_GotFocus(object sender, RoutedEventArgs e)
        {
            if (Find_textBox.Text == "Поиску по логину")
            {
                Find_textBox.Text = "";
            }
        }

        private void Find_textBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (Find_textBox.Text == "")
            {
                Find_textBox.Text = "Поиску по логину";
            }
        }

        private void Sort_conboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Sort_conboBox.SelectedIndex == 0)
                UserLogList.ItemsSource = App.Database.UserLog.
                    OrderBy(log => log.date_authorization).ToList();
            else
                UserLogList.ItemsSource = App.Database.UserLog.
                    OrderByDescending(log => log.date_authorization).ToList();
        }
    }
}
